--[[
	Fbclient package version

	local major,minor,build = unpack(require'fbclient.version')

]]

return {0,5,0}

